<?php

require_once(__DIR__ . '/JsonSQL.php');

/*
json model

{
	key: {
		data
	}
}

model de uso da class

$json = new JsonSQL('file.json');

Select Exemples:
$user = $json->select(); return Data From All users
$user = $json->select('Fernando'); return Data From user
$user = $json->select('Fernando', ['amount']); return amount From user

Edit Exemples:
$user = $json->edit(['amount' => 10]); edit amount From All users
$user = $json->edit('Fernando', ['amount' => 10]); edit amount From user

Delete Exemples:
$user = $json->deleta('Fernando'); delete user
$user = $json->deleta('Fernando', ['amount']); delete amount from user

Insert Exemples:
$user = $json->insert('Fernando', [data array]); create user
$user = $json->insert('Fernando', ['amount' => 10]); create amount in user

*/
